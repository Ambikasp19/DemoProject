package runner;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
 
@RunWith(Cucumber.class)

@CucumberOptions(
		features = "src/test/resources/features",
		glue= {"definitions"},
		plugin = { "com.cucumber.listener.ExtentCucumberFormatter:target/output/Report.html"},
		monochrome = true
		)

public class TestRunner {
	@AfterClass
	public static void writeExtentReport() {
	}
}
