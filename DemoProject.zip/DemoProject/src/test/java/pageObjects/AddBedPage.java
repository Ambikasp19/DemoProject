package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import definitions.BaseClass;

public class AddBedPage extends BaseClass {
	
	public AddBedPage(WebDriver driver) {
		super();
		this.wait = (new WebDriverWait(driver, 30));
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.CSS, using = "#linkAddBed") 
	public WebElement btn_AddBed;
	
	@FindBy(how = How.CSS, using = "#addBedHeader")
	public WebElement txtheader_AddBed;
	
	@FindBy(how = How.CSS, using = "#inputBedID") 
	public WebElement txtbx_FrameID;
	
	@FindBy(how = How.CSS, using = "#inputWirelessMAC") 
	public WebElement txtbx_WirelessMAC;
	
	@FindBy(how = How.CSS, using = "#label-Centrak") 
	public WebElement btn_LocatingVendor;
	
	@FindBy(how = How.CSS, using = "#inputAssetTagID") 
	public WebElement txtbx_AssetTag;
	
	@FindBy(how = How.CSS, using = "#btnSaveBed")
	public WebElement btn_Save;
	
	@FindBy(how = How.CSS, using = "div.toast-message")
	public WebElement txt_ToastMessage;
	
	@FindBy(how = How.CSS, using = "#bedTable")
	public WebElement table_WirelessBed;
	
	public void enter_frameID(String frameID) {
		txtbx_FrameID.sendKeys(frameID);
	}
	
	public void enter_mac(String mac) {
		txtbx_WirelessMAC.sendKeys(mac);
	}
	
	public void enter_assetTag(String assetTag) {
		txtbx_AssetTag.sendKeys(assetTag);
	}
	
	public void clickOn_LocatingVendor(){
		btn_LocatingVendor.click();
	}
	
	public void clickOn_AddBed(){
		btn_AddBed.click();
	}
	
	public void clickOn_Save(){
		btn_Save.click();
	}
	
	public void clickOn_ToasterMessage(){
		txt_ToastMessage.click();
	}
	
	public String getAddBedHeaderText() {
		waitForVisibilityOfElement(txtheader_AddBed);
		return txtheader_AddBed.getText();
	}
	
	public String getToasterMessage() {
		waitForVisibilityOfElement(txt_ToastMessage);
		return txt_ToastMessage.getText();
	}
	
	public void waitForVisibilityOfElement(WebElement element){
        wait.until(ExpectedConditions.visibilityOf(element));
	}
	
	public void waitForInvisibilityOfElement(){
        wait.until(ExpectedConditions.invisibilityOf(txt_ToastMessage));
	}
	
	public void fill_AddBedDetails(String frameId, String mac, String tag) {
		txtbx_FrameID.sendKeys(frameId);
		txtbx_WirelessMAC.sendKeys(mac);
		txtbx_AssetTag.sendKeys(tag);
		btn_LocatingVendor.click();
		btn_Save.click();
	}
}
