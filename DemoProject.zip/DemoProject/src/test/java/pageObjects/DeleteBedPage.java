package pageObjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import definitions.BaseClass;

public class DeleteBedPage extends BaseClass {
	public DeleteBedPage(WebDriver driver) {
		super();
		this.wait = (new WebDriverWait(driver, 60));
	    PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.CSS, using = "#checkSelectAll") 
	private WebElement btn_checkBox;
	
	@FindBy(how = How.CSS, using = "#linkDeleteBed")
	private WebElement btn_DeleteBed;
	
	@FindBy(how = How.CSS, using = "#confirmDeleteYes")
	private WebElement btn_Delete;
	
	@FindBy(how = How.CSS, using = "div.toast-message")
	private WebElement txt_ToastMessage;
	
	public void clickOn_CheckBox(){
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", btn_checkBox);
		//btn_checkBox.click();
	}
	
	public void clickOn_DeleteBed(){
		btn_DeleteBed.click();
	}
	
	public void clickOn_Delete(){
		btn_Delete.click();
	}
	
	public String getToasterMessage() {
		waitForVisibilityOfElement(txt_ToastMessage);
		return txt_ToastMessage.getText();
	}
	
	public void waitForVisibilityOfElement(WebElement element){
        wait.until(ExpectedConditions.visibilityOf(element));
	}
	
	public void DeleteBed() {
		clickOn_CheckBox();
		clickOn_DeleteBed();
		clickOn_Delete();
	}
}
