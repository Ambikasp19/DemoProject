package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import definitions.BaseClass;

public class LogoutPage extends BaseClass{
	
	public LogoutPage(WebDriver driver) {
		super();
		this.wait = (new WebDriverWait(driver, 60));
	    PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.CSS, using = "#linkOptions") 
	public WebElement btn_Options;
	
	@FindBy(how = How.CSS, using = "#signOut") 
	public WebElement btn_SignOut;
	
	@FindBy(how = How.CSS, using = "#linkLogin") 
	public WebElement btn_SignIn;
	
	public void signOut() {
		btn_Options.click();
		btn_SignOut.click();
	}
	
	public boolean signInBtnDisplayed() {
		if(btn_SignIn.isDisplayed()){
			return true;
		}
		else {
			return false;
		}		
	}
}
