package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import definitions.BaseClass;

public class LoginPage extends BaseClass{

	public LoginPage(WebDriver driver) {
		super();
		this.wait = (new WebDriverWait(driver, 60));
	    PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.CSS, using = "#linkLogin") 
	public WebElement btn_SignIn1;
	
	@FindBy(how = How.CSS, using = "#linklogin") 
	public WebElement btn_SignIn2;
	
	@FindBy(how = How.CSS, using = "#username") 
	public WebElement txtbx_UserName;
	
	@FindBy(how = How.CSS, using = "#password")
	public WebElement txtbx_Password;
	
	@FindBy(how = How.CSS, using = "#hederText")
	public WebElement txt_HeaderText;
	
	@FindBy(how = How.CSS, using = "#loadingIcon")
	public WebElement loadingIcon;
	
	public void enter_userName(String userName) {
		txtbx_UserName.sendKeys(userName);
	}
	
	public void enter_password(String password) {
		txtbx_Password.sendKeys(password);
	}
	
	public void clickOn_SignInBtn1(){
		btn_SignIn1.click();
	}
	
	public void clickOn_SignInBtn2(){
		btn_SignIn2.click();
	}
	
	public String getHeaderText() {
		waitForVisibilityOfElement(txt_HeaderText);
		return txt_HeaderText.getText();
	}
	
	public void waitForInvisibilityOfLoadingIcon(){
        wait.until(ExpectedConditions.invisibilityOf(loadingIcon));
	}
	
	public void waitForVisibilityOfElement(WebElement element){
        wait.until(ExpectedConditions.visibilityOf(element));
	}
	
	public void login(String userName, String password) {
		btn_SignIn1.click();
		waitForVisibilityOfElement(txtbx_UserName);
		txtbx_UserName.sendKeys(userName);
		txtbx_Password.sendKeys(password);
		btn_SignIn2.click();
	}
}
