package definitions;

import java.io.File;

import org.testng.Assert;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.AddBedPage;
import pageObjects.DeleteBedPage;
import pageObjects.LoginPage;
import pageObjects.LogoutPage;
import dataProvider.ConfigFileReader;
import managers.FileReaderManager;

public class WirelessBedSteps extends BaseClass{
	LoginPage loginPage;
	AddBedPage addBed;
	DeleteBedPage deleteBed;
	LogoutPage logOut;
	
	static ExtentReports report;
	static ExtentTest test;
	
	@Given("^User is on Home Page$")
	public void user_is_on_Home_Page() throws Throwable {
		report = new ExtentReports(FileReaderManager.getInstance().getConfigReader().getReportPath(), true);
		report.loadConfig(new File(FileReaderManager.getInstance().getConfigReader().getReportConfigPath()));
		test = report.startTest("Login to Device Manager");
		test.assignAuthor("Preethi");
		
		ConfigFileReader configFileReader= new ConfigFileReader();
		loadWebBrowser();
		test.log(LogStatus.INFO, "Web Browser launched successfully!!!");
		String baseUrl = configFileReader.getApplicationUrl();
        driver.get(baseUrl);
        test.log(LogStatus.INFO, "Navigated to Device Manager!!!");
        Assert.assertEquals(driver.getTitle(), "Device Manager"); 
        test.log(LogStatus.PASS, "User is on Home page!!!");
	}

	@When("^User enters username as \"([^\"]*)\" and password as \"([^\"]*)\"$")
	public void user_enters_username_as_and_password_as(String username, String password) throws Throwable {
		loginPage = new LoginPage(driver);
		loginPage.waitForInvisibilityOfLoadingIcon();
		loginPage.login(username, password);
		test.log(LogStatus.INFO, "User successfully logged into Device Manager!");	
	}

	@Then("^Header displayed Device Manager$")
	public void header_displayed_Device_Manager() throws Throwable {
		//loginPage = new LoginPage(driver);
		Assert.assertEquals(loginPage.getHeaderText(), "Device Manager (Administrator)");
		String screenShotPath = GetScreenShot.capture(driver, "Device Manager");
		test.log(LogStatus.PASS, "'" + loginPage.getHeaderText()+ "' header is displayed!!!" + test.addScreenCapture(screenShotPath));
		report.endTest(test);
	}
	
	@Given("^User is on Add Bed Page$")
	public void user_is_on_Add_Bed_Page() throws Throwable {
		test = report.startTest("Add Bed");
		test.assignAuthor("Preethi");
		addBed = new AddBedPage(driver);
		addBed.clickOn_AddBed();
        Assert.assertEquals(addBed.getAddBedHeaderText(), "Add Bed");
        test.log(LogStatus.INFO, "User is on add bed page!!!");
	}

	@When("^User enters FrameID as \"([^\"]*)\", WirelessMAC as \"([^\"]*)\" and AssetTag as \"([^\"]*)\"$")
	public void user_enters_FrameID_as_WirelessMAC_as_and_AssetTag_as(String frameID, String mac, String tag) throws Throwable {
		addBed = new AddBedPage(driver);
		addBed.fill_AddBedDetails(frameID, mac, tag);
		String screenShotPath = GetScreenShot.capture(driver, "Add Bed");
		test.log(LogStatus.INFO, "Add Bed details were entered!!!" + test.addScreenCapture(screenShotPath));
	}
	
	@When("^User enters \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\" in Add Bed Page$")
	public void user_enters_and_in_Add_Bed_Page(String frameID, String mac, String assetTag) throws Throwable {
		addBed = new AddBedPage(driver);
		addBed.fill_AddBedDetails(frameID, mac, assetTag);
		String screenShotPath = GetScreenShot.capture(driver, "Add Bed");
		test.log(LogStatus.INFO, "Add Bed details were entered!!!" + test.addScreenCapture(screenShotPath));
	}

	@Then("^Message displayed Bed added successfully$")
	public void message_displayed_Bed_added_successfully() throws Throwable {
		addBed = new AddBedPage(driver);
		Assert.assertEquals(addBed.getToasterMessage(), "Bed added successfully!");
		String screenShotPath = GetScreenShot.capture(driver, "Toaster Message");
		test.log(LogStatus.PASS, "'" + addBed.getToasterMessage() + "' message displayed!!!" + test.addScreenCapture(screenShotPath));
		addBed.clickOn_ToasterMessage();
		report.endTest(test);
	}
	
	@When("^User selects Bed and Delete$")
	public void user_selects_Bed_and_Delete() throws Throwable {
		test = report.startTest("Delete Bed");
		test.assignAuthor("Preethi");
		deleteBed = new DeleteBedPage(driver);
	    deleteBed.DeleteBed();
	    test.log(LogStatus.INFO, "Bed deleted successfully!!!");
	}
	
	@Then("^Message displayed Bed deleted successfully$")
	public void message_displayed_Bed_deleted_successfully() throws Throwable {
		deleteBed = new DeleteBedPage(driver);
		Assert.assertEquals(deleteBed.getToasterMessage(), "Bed(s) deleted successfully!");
		String screenShotPath = GetScreenShot.capture(driver, "Toaster Message1");
		test.log(LogStatus.PASS, "'" + deleteBed.getToasterMessage() + "' message displayed!!!" + test.addScreenCapture(screenShotPath));
		report.endTest(test);
	}
	
	@When("^User clicks on logout button$")
	public void user_clicks_on_logout_button() throws Throwable {
		test = report.startTest("Log Out from Device Manager");
		test.assignAuthor("Preethi");
		logOut = new LogoutPage(driver);
		logOut.signOut();
		String screenShotPath = GetScreenShot.capture(driver, "Sign out");
		test.log(LogStatus.INFO, "Sign out button clicked" + test.addScreenCapture(screenShotPath));
	}

	@Then("^SignIn button is displayed on Device Manager$")
	public void signin_button_is_displayed_on_Device_Manager() throws Throwable {
		logOut = new LogoutPage(driver);
		Assert.assertTrue(logOut.signInBtnDisplayed(), "Sign-In button displayed on Device Manager");
		test.log(LogStatus.PASS, "User logged out successfully!!!");
		report.endTest(test);
		report.flush();
        report.close();
		closeWebBrowser();
	}
}