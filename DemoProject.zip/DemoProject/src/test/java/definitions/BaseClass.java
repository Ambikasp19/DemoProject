package definitions;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import dataProvider.ConfigFileReader;

public class BaseClass {
	
	public static WebDriver driver;
    public WebDriverWait wait;
 
    public WebDriver getDriver() {
        return driver;
    }
 
    @BeforeClass
    public void loadWebBrowser () {
    	ConfigFileReader configFileReader = new ConfigFileReader();
		System.setProperty("webdriver.chrome.driver", configFileReader.getDriverPath());
    	
    	//Create a Chrome driver. All test classes use this.
        driver = new ChromeDriver();
 
        //Create a wait. All test classes use this.
        wait = new WebDriverWait(driver, 60);
 
        //Maximize Window
        driver.manage().window().maximize();
    }
 
    @AfterClass
    public void closeWebBrowser () {
        driver.quit();
    }

}
